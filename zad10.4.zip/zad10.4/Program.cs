﻿using System;

namespace zad10._4
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,] miasta = new string[2, 5];
            for(int i=0;i<2;i++)
            {
                for(int j = 0; j < 5; j++)
                {
                    miasta[i, j] = Console.ReadLine();
                    Console.WriteLine(miasta[i, j]+"\n");
                }
            }
            
        }
    }
}
